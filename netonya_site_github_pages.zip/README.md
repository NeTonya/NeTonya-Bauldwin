# Personal site for NeTonya Bauldwin

This is a static site (HTML + one image). No build step required.

## Publish on GitHub Pages (free)

1. Create a new repo at https://github.com/new  (e.g., `netonya-site`).
2. Upload `index.html` and the `assets/` folder (drag/drop both into the repo).
3. In the repo: **Settings → Pages** → **Build and deployment** → Source: **Deploy from a branch**.
4. Select **Branch: main / Root** → Save.
5. Wait 1–2 minutes. Your site will appear at: `https://<your-username>.github.io/netonya-site/`.

## Open locally
Just double-click `index.html` to open it in Chrome/Safari/Edge.

---
Links used in the page:
- LinkedIn: https://www.linkedin.com/in/netonya-black-bauldwin-88a130b
- YouTube: https://www.youtube.com/@netonyab697
- Facebook: https://www.facebook.com/netonyab
- Email: mailto:netonya@yahoo.com
